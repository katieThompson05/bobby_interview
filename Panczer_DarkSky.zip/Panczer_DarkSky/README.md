# Elements

A homepage for telling the time and weather using the Dark Skys API. The page uses the current time and your location to show you the current weather and temperature. The page is also styled based on if it is morning, noon, evening or night.

### Prerequisites

You'll need to have the following installed on your system:
* Node.js

### Running the project

This project was build with Preact, a slimmed down version of the React library

To install needed packages in the `package.json`, run
```
npm install
```

To build and start the project in dev mode with hot reload
```
npm start
```

To build the project
```
npm run-scripts build
```

Use your current location to load the weather or click on the cog icon on the lower right to open up a menu to input your own coordinates and timeframe.
Default location is set to Boulder, CO.

## Author

* **Bobby Panczer** - [GitHub](https://github.com/rpanczer)

