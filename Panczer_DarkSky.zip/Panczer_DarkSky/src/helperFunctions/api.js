import fetch from 'isomorphic-fetch';

export function getWeather(lat,long) {
  const params = {
    headers: {
      "content-type": "application/json; charset=UTF-8",
      "Access-Control-Allow-Origin": "*"
    },
    method: "GET"
  };
  return fetch(`https://thingproxy.freeboard.io/fetch/https://api.darksky.net/forecast/e2d745177d99c5764d08f5efcf230f16/${lat},${long}`, params)
    .then(function (data) {
      if (!data.ok) { return new Error('Could not return weather information') }
      return data.json()
    });
}

export function getCustomWeather(lat,long,time) {
  const params = {
    headers: {
      "content-type": "application/json; charset=UTF-8",
      "Access-Control-Allow-Origin": "*"
    },
    method: "GET"
  };
  return fetch(`https://thingproxy.freeboard.io/fetch/https://api.darksky.net/forecast/e2d745177d99c5764d08f5efcf230f16/${lat},${long},${time}`, params)
  .then(function (data) {
    if (!data.ok) { return new Error('Could not return custom weather information') }
    return data.json()
  });
}
