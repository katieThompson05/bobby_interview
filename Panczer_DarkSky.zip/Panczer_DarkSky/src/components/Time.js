import { h, render, Component } from "preact";
import Skycons from 'react-skycons'

class Time extends Component {
  render() { 
    const {
      time,
      temp,
      weatherType
    } = this.props

    let formattedWeatherType = weatherType.replace("-","_").toUpperCase()
    let WeatherIcon = (
      <Skycons 
        color='white' 
        icon={formattedWeatherType}
        autoplay={true}
      />
    )

    return (
      <div className='TimeComponent'>
        <div className="time-container">
          {time}
        </div>
        <div className="details-container">
          {temp + "°F"}
          <div className="weather-icon-container">
            {WeatherIcon}
          </div>
        </div>
      </div>
    );
  }
}

export default Time;
