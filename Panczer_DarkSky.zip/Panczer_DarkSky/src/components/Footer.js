import { h, render, Component } from "preact";

class Footer extends Component {
  state = {
    isOpen: false,
    date: ''
  }
  constructor(props) {
    super(props);
    this.toggle = this.toggle.bind(this);
  } 
  componentWillMount () {
    let date = new Date()
    let day = date.getDay()
    let month = date.getMonth()
    let day_num = date.getDate()
    let days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    let months = ['Jan','Feb','Mar','Apr','May','June','July','Aug','Sept','Oct','Nov','Dec']
    this.setState({ date: days[day] + ' ' + months[month] + ' ' + day_num})
  }

  toggle () {
    this.setState({isOpen: !this.state.isOpen},()=>{console.log("toggled",this.state.isOpen)})
  }

  handleCustomWeather () {
    const {
      toggleCustomWeather
    } = this.props

    let datetime = new Date("2015-08-25T15:35:58.000Z");
    let time = datetime.getTime() / 1000
    let lat = "40.3493"
    let long = "-80.04352"
    toggleCustomWeather(lat,long,time)
  }

  render() {  
    const { 
      lat,
      long,
    } = this.props

    const Content = (
      <div>
        <div className='menu-details'>
          <p className="label">Custom Location: </p>
          <input className="input" type="number" name="custom-lat" placeholder="Input a Latitude: 40.2342"></input>
          <input className="input" type="number" name="custom-long" placeholder="Input a Longitude: -74.324"></input>
        </div>
        <div className='menu-details'>
          <p className="label">Custom Date: </p>
          <input className="input-small" type="number" name="custom-month" placeholder="MO"></input>
          <input className="input-small" type="number" name="custom-day" placeholder="DD"></input>
          <input className="input-medium" type="number" name="custom-year" placeholder="YYYY"></input>
          <p className="label">Custom Time: </p>
          <input className="input-small" type="number" name="custom-hour" placeholder="HH"></input>
          <input className="input-small" type="number" name="custom-minute" placeholder="MM"></input>
          <button className="button" onClick={()=>{handleCustomWeather(this.state.customTime,this.state.customLat,this.state.customLong)}}>Update</button>
          <button className="button" onClick={()=>{location.reload()}}>Refresh</button>
        </div>
      </div>
    )
    return (
      <div>
        {this.state.isOpen ? Content : null}
        <div className='menu-bar' onClick={this.toggle}>
          <div>
            {this.state.date}
          </div>
          <div>
            <p>{`Location: ${lat}, ${long}`}</p>
          </div>
          <div>
            <i class="fas fa-cogs"></i>
          </div>
        </div>
      </div>
    )
  }
}

export default Footer
