import { h, render, Component } from "preact";
import Time from "./Time";
import Footer from "./Footer"
import {getWeather,getCustomWeather} from "../helperFunctions/api"
import _ from 'lodash'

class App extends Component {
  state = {
    lat: '40.016457',
    long: '-105.285884',
    TOD: 'morning',
    time: new Date(Date.now()).toLocaleTimeString(),
    enableCustomWeather: false,
    customWeather: '',
    weatherType: 'Snow',
    temp: '--'
  }

  componentWillMount () {
    this.setTimeofDay()
  }

  componentDidMount () {
    const {
      lat,
      long
    } = this.state
    // update the time every second
    this.interval = setInterval(() => this.setState({ time: new Date(Date.now()).toLocaleTimeString() }), 1000)
    // check time of day every 15 minutes
    this.interval1 = setInterval(() => this.setTimeofDay(), 900000)
    // get weather info every 15 minutes
    this.interval2 = setInterval(() => getWeather(parseFloat(lat),parseFloat(long)), 900000)
    this.getLocation()
  }

  componentWillUpdate () {
    const {
      enableCustomWeather
    } = this.state

    if (enableCustomWeather) {
      clearInterval(this.interval);
      clearInterval(this.interval1);
      clearInterval(this.interval2);
      this.rotateWeather()
    } else if (!enableCustomWeather && _.isNil(this.interval)) {
      const {
        lat,
        long
      } = this.state
      this.interval = setInterval(() => this.setState({ time: new Date(Date.now()).toLocaleTimeString() }), 1000)
      this.interval1 = setInterval(() => this.setTimeofDay(), 900000)
      this.interval2 = setInterval(() => getWeather(parseFloat(lat),parseFloat(long)), 900000)
    }
  }

  componentWillUnmount() {
    clearInterval(this.interval);
    clearInterval(this.interval1);
    clearInterval(this.interval2);
  }

  getLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position)=>{
        this.setState({lat: position.coords.latitude, long:position.coords.longitude},()=>{this.setWeather()})
      })
    }
  }

  setWeather () {
    const {
      lat,
      long
    } = this.state

    getWeather(parseFloat(lat),parseFloat(long)).then((data) =>{
      this.setState({weatherType: data.currently.icon, temp: data.currently.temperature})
      return data
    }).catch((error) => {
      console.log(error.message);
    })
  }

  setTimeofDay () {
    let hour = new Date(Date.now()).getHours()
    if (hour < 5) {
      this.setState({TOD: "night"})
    } else if (hour < 12) {
      this.setState({TOD: "morning"})
    } else if (hour < 18) {
      this.setState({TOD: "noon"})
    } else if (hour < 21) {
      this.setState({TOD: "evening"})
    } else {
      this.setState({TOD: "night"})
    }
  }

  toggleCustomWeather (lat,long,time) {
    this.setState({enableCustomWeather: !this.state.enableCustomWeather}, ()=>{this.customWeather(lat,long,time)})
  }

  customWeather (lat,long,time) {
    if (enableCustomWeather) {
      getCustomWeather(lat,long,time).then((value)=>{this.setState({customWeather: JSON.stringify(value)})})
    }
  }

  rotateWeather () {
    while (this.state.enableCustomWeather) {
      for (let i = 0; i < weather.length; i++) {
        this.setState({time: weather[i].time, weatherType: weather[i].type, temp: weather[i].temp})
      }
    }
  }

  render() {
    const {
      TOD,
      time,
      lat,
      long,
      weatherType,
      temp
    } = this.state

    let trimmed_lat = parseFloat(lat).toFixed(4)
    let trimmed_long = parseFloat(long).toFixed(4)

    return (
      <div className={`main time-${TOD}`}>
        <Time 
          time = {time}
          weatherType = {weatherType}
          temp = {temp}

        />
        <Footer 
          lat = {trimmed_lat}
          long = {trimmed_long}
          toggleCustomWeather = {(lat,long,time) => {this.toggleCustomWeather(lat,long,time)}}
        />
      </div>
    );
  }
}

export default App;
