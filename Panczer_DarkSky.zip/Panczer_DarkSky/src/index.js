import { h, render, Component } from 'preact';
import preactDOM from 'preact-dom';
import App from './components/App';
import 'normalize.css';
import './main.css';

render(<App />, document.getElementById('app'))
